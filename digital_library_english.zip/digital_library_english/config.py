import tkinter as tk
import json
import os
import hashlib


APP_WIDTH = 1280
APP_HEIGHT = 720

USERS_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "users.json")
BOOKS_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "books.json")
BORROWINGS_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "borrowings.json")


COLOR_PRIMARY = "#00050a"
COLOR_ACCENT = "#c70606"
COLOR_ACCENT_DARK = "#960404"
COLOR_BG = "#f4f6f7"
COLOR_CARD = "#ffffff"
COLOR_TEXT = "#2c3e50"
COLOR_MUTED = "#7f8c8d"
COLOR_SUCCESS = "#27ae60"
COLOR_DANGER = "#ff1900"


FONT_TITLE = ("Segoe UI", 26, "bold")
FONT_SUBTITLE = ("Segoe UI", 12)
FONT_NAV = ("Segoe UI", 11, "bold")
FONT_CARD_TITLE = ("Segoe UI", 14, "bold")
FONT_CARD_BODY = ("Segoe UI", 10)
FONT_LABEL = ("Segoe UI", 11)
FONT_BUTTON = ("Segoe UI", 11, "bold")


LIBRARY_ARTICLES = [
    {
        "title": "Top 5 Best Selling Fiction Books",
        "summary": "Find 5 of the best fiction novels around the world."
                     "Everything from Romance, to Action, to Horror novels",
        "category": "Recommendation",
    },
    {
        "title": "Effective Tips To Read Faster",
        "summary": "Learn more about speed reading so you can enjoy more stories"
                     "without losing track",
        "category": "Tips & Tricks",
    },
    {
        "title": "Opening and Visiting Hours",
        "summary": "Library is open every weekday from 08.00 AM to 4.00 PM. "
                     "Check the full schedule here",
        "category": "Announcement",
    },
    {
        "title": "How to Borrow Books From the Library",
        "summary": "After logging in, members and customers can borrow books at anytime."
                     "Books can be taken from the front desk at the library",
        "category": "Guide",
    },
]


DEFAULT_BOOKS = [
    {"id": 0, "judul": "Laskar Pelangi", "penulis": "Andrea Hirata", "tahun": "2005", "stok": 5},
    {"id": 1, "judul": "Bumi", "penulis": "Tere Liye", "tahun": "2014", "stok": 3},
    {"id": 2, "judul": "Atomic Habits", "penulis": "James Clear", "tahun": "2018", "stok": 4},
    {"id": 3, "judul": "To Kill a Mockingbird", "penulis": "Harper Lee", "tahun": "1960", "stok": 8}
]


def hash_password(password: str) -> str:
    return hashlib.sha256(password.encode("utf-8")).hexdigest()


def load_users() -> dict:
    if not os.path.exists(USERS_FILE):
        return {}
    try:
        with open(USERS_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError):
        return {}


def save_users(users: dict) -> None:
    with open(USERS_FILE, "w", encoding="utf-8") as f:
        json.dump(users, f, indent=2, ensure_ascii=False)


def register_user(username: str, email: str, password: str) -> tuple[bool, str]:
    users = load_users()
    if username in users:
        return False, "Username is already registered. Please choose another username."
    for data in users.values():
        if data.get("email", "").lower() == email.lower():
            return False, "Email is already registered. Please use another email address."
    users[username] = {
        "email": email,
        "password": hash_password(password),
    }
    save_users(users)
    return True, "Registration successful! Please log in."


def verify_login(username: str, password: str) -> tuple[bool, str]:
    users = load_users()
    if username not in users:
        return False, "Username not found."
    if users[username]["password"] != hash_password(password):
        return False, "Incorrect password."
    return True, "Login successful!"


def delete_user(username: str) -> tuple[bool, str]:
    users = load_users()
    if username not in users:
        return False, "User not found."
    del users[username]
    save_users(users)
    return True, "User deleted successfully."


def update_user(old_username: str, new_username: str, email: str, new_password: str = "") -> tuple[bool, str]:
    users = load_users()
    if old_username not in users:
        return False, "User not found."
    if new_username != old_username and new_username in users:
        return False, "The new username is already in use."
    for uname, data in users.items():
        if uname != old_username and data.get("email", "").lower() == email.lower():
            return False, "The email is already in use by another user."
    record = users.pop(old_username)
    record["email"] = email
    if new_password:
        record["password"] = hash_password(new_password)
    users[new_username] = record
    save_users(users)
    return True, "User updated successfully."


def load_books() -> list:
    if not os.path.exists(BOOKS_FILE):
        save_books(DEFAULT_BOOKS)
        return list(DEFAULT_BOOKS)
    try:
        with open(BOOKS_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
            if isinstance(data, list):
                return data
            return []
    except (json.JSONDecodeError, OSError):
        return []


def save_books(books: list) -> None:
    with open(BOOKS_FILE, "w", encoding="utf-8") as f:
        json.dump(books, f, indent=2, ensure_ascii=False)


def get_next_book_id(books: list) -> int:
    if not books:
        return 1
    return max(int(b.get("id", 0)) for b in books) + 1


def add_book(judul: str, penulis: str, tahun: str, stok: int) -> tuple[bool, str]:
    books = load_books()
    new_id = get_next_book_id(books)
    books.append({"id": new_id, "judul": judul, "penulis": penulis, "tahun": tahun, "stok": stok})
    save_books(books)
    return True, "Book successfully ditambahkan."


def update_book(book_id: int, judul: str, penulis: str, tahun: str, stok: int) -> tuple[bool, str]:
    books = load_books()
    for b in books:
        if int(b.get("id", 0)) == int(book_id):
            b["judul"] = judul
            b["penulis"] = penulis
            b["tahun"] = tahun
            b["stok"] = stok
            save_books(books)
            return True, "Book successfully diperbarui."
    return False, "Book not ditemukan."


def delete_book(book_id: int) -> tuple[bool, str]:
    books = load_books()
    borrowings = load_borrowings()
    for p in borrowings:
        if int(p.get("book_id", 0)) == int(book_id) and p.get("status") == "Borrowed":
            return False, "Book not bisa dihapus karena is currently borrowed."
    filtered = [b for b in books if int(b.get("id", 0)) != int(book_id)]
    if len(filtered) == len(books):
        return False, "Book not ditemukan."
    save_books(filtered)
    return True, "Book successfully dihapus."


def find_book(book_id: int):
    for b in load_books():
        if int(b.get("id", 0)) == int(book_id):
            return b
    return None


def adjust_book_stock(book_id: int, delta: int) -> bool:
    books = load_books()
    for b in books:
        if int(b.get("id", 0)) == int(book_id):
            b["stok"] = int(b.get("stok", 0)) + delta
            if b["stok"] < 0:
                return False
            save_books(books)
            return True
    return False


def load_borrowings() -> list:
    if not os.path.exists(BORROWINGS_FILE):
        return []
    try:
        with open(BORROWINGS_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
            if isinstance(data, list):
                return data
            return []
    except (json.JSONDecodeError, OSError):
        return []


def save_borrowings(borrowings: list) -> None:
    with open(BORROWINGS_FILE, "w", encoding="utf-8") as f:
        json.dump(borrowings, f, indent=2, ensure_ascii=False)


def get_next_borrowing_id(borrowings: list) -> int:
    if not borrowings:
        return 1
    return max(int(p.get("id", 0)) for p in borrowings) + 1


def add_borrowing(username: str, book_id: int, tanggal_pinjam: str, tanggal_kembali: str) -> tuple[bool, str]:
    users = load_users()
    if username not in users:
        return False, "Username is not registered."
    book = find_book(book_id)
    if book is None:
        return False, "Book not ditemukan."
    if int(book.get("stok", 0)) <= 0:
        return False, "Stock buku habis."
    borrowings = load_borrowings()
    new_id = get_next_borrowing_id(borrowings)
    borrowings.append({
        "id": new_id,
        "username": username,
        "book_id": int(book_id),
        "judul": book.get("judul", ""),
        "tanggal_pinjam": tanggal_pinjam,
        "tanggal_kembali": tanggal_kembali,
        "status": "Borrowed",
    })
    save_borrowings(borrowings)
    adjust_book_stock(book_id, -1)
    return True, "Borrowing successfully ditambahkan."


def update_borrowing(borrow_id: int, username: str, book_id: int, tanggal_pinjam: str, tanggal_kembali: str, status: str) -> tuple[bool, str]:
    borrowings = load_borrowings()
    target = None
    for p in borrowings:
        if int(p.get("id", 0)) == int(borrow_id):
            target = p
            break
    if target is None:
        return False, "Borrowing record not found."
    old_status = target.get("status")
    old_book_id = int(target.get("book_id", 0))
    new_book_id = int(book_id)
    if old_status == "Borrowed" and status == "Returned" and old_book_id == new_book_id:
        adjust_book_stock(old_book_id, 1)
    elif old_status == "Returned" and status == "Borrowed":
        book = find_book(new_book_id)
        if book is None:
            return False, "Book not ditemukan."
        if int(book.get("stok", 0)) <= 0:
            return False, "Stock buku habis."
        adjust_book_stock(new_book_id, -1)
    elif old_book_id != new_book_id and old_status == "Borrowed" and status == "Borrowed":
        book = find_book(new_book_id)
        if book is None:
            return False, "Book not ditemukan."
        if int(book.get("stok", 0)) <= 0:
            return False, "Stock buku habis."
        adjust_book_stock(old_book_id, 1)
        adjust_book_stock(new_book_id, -1)
    target["username"] = username
    target["book_id"] = new_book_id
    book_now = find_book(new_book_id)
    if book_now is not None:
        target["judul"] = book_now.get("judul", target.get("judul", ""))
    target["tanggal_pinjam"] = tanggal_pinjam
    target["tanggal_kembali"] = tanggal_kembali
    target["status"] = status
    save_borrowings(borrowings)
    return True, "Borrowing record updated successfully."


def delete_borrowing(borrow_id: int) -> tuple[bool, str]:
    borrowings = load_borrowings()
    target = None
    for p in borrowings:
        if int(p.get("id", 0)) == int(borrow_id):
            target = p
            break
    if target is None:
        return False, "Borrowing record not found."
    if target.get("status") == "Borrowed":
        adjust_book_stock(int(target.get("book_id", 0)), 1)
    filtered = [p for p in borrowings if int(p.get("id", 0)) != int(borrow_id)]
    save_borrowings(filtered)
    return True, "Borrowing record deleted successfully."


def build_sidebar(parent, controller, active_page=None, show_user=True):
    """Build the application's fixed vertical navigation sidebar."""
    sidebar = tk.Frame(parent, bg=COLOR_PRIMARY, width=220)
    sidebar.pack(side="left", fill="y")
    sidebar.pack_propagate(False)

    tk.Label(
        sidebar, text="Zhu Library", bg=COLOR_PRIMARY, fg="white",
        font=("Segoe UI", 18, "bold")
    ).pack(fill="x", padx=20, pady=(28, 35))

    nav_items = [
        ("Home", "HomePage"),
        ("Books", "BookManagementPage"),
        ("Borrowing", "BorrowingManagementPage"),
        ("Users", "UsersManagementPage"),
    ]
    for label, page in nav_items:
        selected = page == active_page
        HoverButton(
            sidebar,
            bg_normal=COLOR_ACCENT if selected else COLOR_PRIMARY,
            bg_hover=COLOR_ACCENT_DARK if selected else "#34495e",
            text=label, fg="white", font=FONT_NAV, bd=0,
            cursor="hand2", anchor="w", padx=20, pady=10,
            command=lambda p=page: controller.show_frame(p)
        ).pack(fill="x", padx=12, pady=3)

    spacer = tk.Frame(sidebar, bg=COLOR_PRIMARY)
    spacer.pack(fill="both", expand=True)

    if controller.current_user:
        if show_user:
            tk.Label(
                sidebar, text=f"👤 {controller.current_user}", bg=COLOR_PRIMARY,
                fg="white", font=FONT_NAV, anchor="w"
            ).pack(fill="x", padx=20, pady=(0, 12))
        HoverButton(
            sidebar, bg_normal="#c0392b", bg_hover="#a93226",
            text="Logout", fg="white", font=FONT_NAV, bd=0,
            cursor="hand2", anchor="w", padx=20, pady=10,
            command=controller.logout
        ).pack(fill="x", padx=12, pady=(0, 20))
    else:
        HoverButton(
            sidebar, bg_normal=COLOR_PRIMARY, bg_hover="#34495e",
            text="Log In", fg="white", font=FONT_NAV, bd=0,
            cursor="hand2", anchor="w", padx=20, pady=10,
            command=lambda: controller.show_frame("SignInPage")
        ).pack(fill="x", padx=12, pady=3)
        HoverButton(
            sidebar, bg_normal=COLOR_ACCENT, bg_hover=COLOR_ACCENT_DARK,
            text="Sign Up", fg="white", font=FONT_NAV, bd=0,
            cursor="hand2", anchor="w", padx=20, pady=10,
            command=lambda: controller.show_frame("SignUpPage")
        ).pack(fill="x", padx=12, pady=(3, 20))
    return sidebar


class HoverButton(tk.Button):
    def __init__(self, master, bg_normal, bg_hover, **kwargs):
        super().__init__(master, bg=bg_normal, activebackground=bg_hover, **kwargs)
        self.bg_normal = bg_normal
        self.bg_hover = bg_hover
        self.bind("<Enter>", lambda e: self.config(bg=self.bg_hover))
        self.bind("<Leave>", lambda e: self.config(bg=self.bg_normal))