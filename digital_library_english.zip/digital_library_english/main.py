import tkinter as tk

from config import APP_WIDTH, APP_HEIGHT, COLOR_PRIMARY, COLOR_ACCENT, COLOR_ACCENT_DARK, COLOR_BG, FONT_NAV, HoverButton
from homepage import HomePage
from signup import SignUpPage
from signin import SignInPage
from bookmanagement import BookManagementPage
from borrowingmanagement import BorrowingManagementPage
from usersmanagement import UsersManagementPage


class LibraryApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Zhu Library")
        self.geometry(f"{APP_WIDTH}x{APP_HEIGHT}")
        self.resizable(False, False)
        self.configure(bg=COLOR_BG)

        self.current_user = None
        self.nav_buttons = {}

        # Main vertical navigation sidebar
        self.sidebar = tk.Frame(self, bg=COLOR_PRIMARY, width=220)
        self.sidebar.pack(side="left", fill="y")
        self.sidebar.pack_propagate(False)

        tk.Label(
            self.sidebar, text="Zhu Library", bg=COLOR_PRIMARY, fg="white",
            font=("Segoe UI", 18, "bold")
        ).pack(fill="x", padx=20, pady=(28, 35))

        nav_items = [
            ("Home", "HomePage"),
            ("Books", "BookManagementPage"),
            ("Borrowing", "BorrowingManagementPage"),
            ("Users", "UsersManagementPage"),
        ]
        for label, page in nav_items:
            button = HoverButton(
                self.sidebar,
                bg_normal=COLOR_PRIMARY,
                bg_hover="#34495e",
                text=label, fg="white", font=FONT_NAV, bd=0,
                cursor="hand2", anchor="w", padx=20, pady=10,
                command=lambda p=page: self.show_frame(p)
            )
            button.pack(fill="x", padx=12, pady=3)
            self.nav_buttons[page] = button

        # Push authentication controls to the bottom of the sidebar.
        spacer = tk.Frame(self.sidebar, bg=COLOR_PRIMARY)
        spacer.pack(fill="both", expand=True)

        self.user_label = tk.Label(
            self.sidebar, text="", bg=COLOR_PRIMARY, fg="white",
            font=FONT_NAV, anchor="w"
        )
        self.user_label.pack(fill="x", padx=20, pady=(0, 12))

        self.login_button = HoverButton(
            self.sidebar, bg_normal=COLOR_PRIMARY, bg_hover="#34495e",
            text="Log In", fg="white", font=FONT_NAV, bd=0,
            cursor="hand2", anchor="w", padx=20, pady=10,
            command=lambda: self.show_frame("SignInPage")
        )
        self.signup_button = HoverButton(
            self.sidebar, bg_normal=COLOR_ACCENT, bg_hover=COLOR_ACCENT_DARK,
            text="Sign Up", fg="white", font=FONT_NAV, bd=0,
            cursor="hand2", anchor="w", padx=20, pady=10,
            command=lambda: self.show_frame("SignUpPage")
        )
        self.logout_button = HoverButton(
            self.sidebar, bg_normal="#c0392b", bg_hover="#a93226",
            text="Logout", fg="white", font=FONT_NAV, bd=0,
            cursor="hand2", anchor="w", padx=20, pady=10,
            command=self.logout
        )

        container = tk.Frame(self, bg=COLOR_BG)
        container.pack(side="left", fill="both", expand=True)
        container.grid_rowconfigure(0, weight=1)
        container.grid_columnconfigure(0, weight=1)

        self.frames = {}
        for PageClass in (HomePage, SignUpPage, SignInPage, BookManagementPage, BorrowingManagementPage, UsersManagementPage):
            page_name = PageClass.__name__
            frame = PageClass(parent=container, controller=self)
            self.frames[page_name] = frame
            frame.grid(row=0, column=0, sticky="nsew")

        self.show_frame("HomePage")

    def _update_sidebar(self, active_page):
        for page, button in self.nav_buttons.items():
            selected = page == active_page
            button.bg_normal = COLOR_ACCENT if selected else COLOR_PRIMARY
            button.bg_hover = COLOR_ACCENT_DARK if selected else "#34495e"
            button.config(bg=button.bg_normal, activebackground=button.bg_hover)

        if self.current_user:
            self.user_label.config(text=f"👤 {self.current_user}")
            self.login_button.pack_forget()
            self.signup_button.pack_forget()
            self.logout_button.pack(fill="x", padx=12, pady=(0, 20))
        else:
            self.user_label.config(text="")
            self.logout_button.pack_forget()
            self.login_button.pack(fill="x", padx=12, pady=3)
            self.signup_button.pack(fill="x", padx=12, pady=(3, 20))

    def show_frame(self, page_name: str):
        frame = self.frames[page_name]
        if hasattr(frame, "on_show"):
            frame.on_show()
        frame.tkraise()
        self._update_sidebar(page_name)

    def set_current_user(self, username: str):
        self.current_user = username
        self._update_sidebar("BookManagementPage")

    def logout(self):
        self.current_user = None
        self.show_frame("HomePage")


if __name__ == "__main__":
    app = LibraryApp()
    app.mainloop()
